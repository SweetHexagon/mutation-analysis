package com.example.pojo;

import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;

public class ParsedFile {
    public final ParseTree tree;
    public final CommonTokenStream tokens;

    public ParsedFile(ParseTree tree, CommonTokenStream tokens) {
        this.tree = tree;
        this.tokens = tokens;
    }
}

