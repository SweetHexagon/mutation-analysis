package com.example.parser;

import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import com.example.javaparser.Java20Parser;
import com.example.javaparser.Java20BaseListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Splits a compilation-unit parse tree into a list of methodDeclaration sub-trees.
 */
public class FunctionSplitter {

    /**
     * Walks the compilation-unit parse tree and collects each
     * methodDeclaration subtree into its own list entry.
     */
    public static List<ParseTree> splitIntoFunctionTrees(ParseTree compilationUnit) {
        List<ParseTree> functions = new ArrayList<>();
        ParseTreeWalker.DEFAULT.walk(new Listener(functions), compilationUnit);
        return functions;
    }

    /**
     * Internal ANTLR listener that collects methodDeclaration nodes.
     */
    private static class Listener extends Java20BaseListener {
        private final List<ParseTree> functions;

        public Listener(List<ParseTree> functions) {
            this.functions = functions;
        }

        @Override
        public void enterMethodDeclaration(Java20Parser.MethodDeclarationContext ctx) {
            functions.add(ctx);
        }
    }
}
