package com.example;

public enum Metrics {
    TREE_EDIT_DISTANCE
}
