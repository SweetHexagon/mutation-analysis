package com.example.test;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class file1 {
    @Test
    public void testSameLengthAll() {
        final Object[] nullArrayObject = null;
        assertTrue(ArrayUtils.isSameLength(nullArrayObject, nullArrayObject));
    }
}